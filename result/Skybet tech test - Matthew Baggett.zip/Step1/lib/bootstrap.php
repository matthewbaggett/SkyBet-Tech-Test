<?php 
// Load in all the required bits of PHP. Usually, we'd use an Autoloader for this...
require_once("../models/person.php");
require_once("../models/people.php"); // Might be better off being called user and users, rather than person and people, actually

